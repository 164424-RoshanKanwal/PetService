package org.springframework.samples.petclinic.dashboard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HystrixDashboardApplicationTests {

    @Test
    void contextLoads() {
    }

}
